-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 15, 2013 at 08:53 
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `web`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE IF NOT EXISTS `about` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `photo` text,
  `name` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `about`
--


-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id_article` int(10) NOT NULL AUTO_INCREMENT,
  `id_category` varchar(25) NOT NULL,
  `judul_post` text,
  `gambar` longtext,
  `isi_post` text,
  `author` varchar(25) NOT NULL,
  `tanggal` datetime NOT NULL,
  PRIMARY KEY (`id_article`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id_article`, `id_category`, `judul_post`, `gambar`, `isi_post`, `author`, `tanggal`) VALUES
(8, 'category_1', 'Jaket Hinata', 'images/images_article/108.jpg', 'kini kami J-fleece hadirkan jaket ala Film anime naruto , yaitu kami ambil dari karakter HINATA.......pasti kerenkan apa lagi bagi para wonder .. :P <br/>\r\n<br/>\r\n- Ukuran : L,M<br/>\r\n- Harga : Rp. 175.000,-\r\n<br/>\r\n<br/>\r\n minat??? silahkan anda HUB. service center kami', 'Admin', '2013-05-01 17:00:00'),
(6, 'category_1', ' A10 Hitam Putih', 'images/images_article/100.jpg', 'kini kami hadirkan jaket keren dan gaya..... seperti halnya trend di KOREA.... yang kini bisa anda pesen di kami.. dengan harga yang murah dan berkualitas..<br/><br/>\r\n\r\n- Ukuran : M,L,XL<br/>\r\n- Harga : Rp. 210.000,-\r\n<br/><br/>\r\nbisa anda beli lewat link yang ada....', 'Admin', '2013-05-03 08:00:00'),
(7, 'category_1', 'R5 Hitam', 'images/images_article/142.jpg', 'yang ini gag kalah keren juga...cocok bagi para Rider... jaket yang kesannya jaket coboy ini...tp masih kesan ala geng motor....<br/><br/>\r\n\r\n- Ukuran : L,M<br/>\r\n- Harga : Rp. 250.000,-', 'Admin', '2013-05-17 11:00:00'),
(1, 'category_1', 'A27X Hitam Merah', 'images/images_article/74.jpg', 'Kini kami menawarkan Sebuah Model Jaket Korea Terbaru Dengan bahan Yang Kualitas Tinggi  Dengan Spesifikasi sebagai berikut :<br/>\r\n<br/>\r\n- Ukuran : S,L,M,XL<br/>\r\n- Warna : Hitam<br/>\r\n- Harga : RP. 210.000,-', 'Admin', '2013-05-03 10:00:00'),
(5, 'category_1', 'A7 Biru Hitam', 'images/images_article/101.jpg', 'yang ini gag kalah keren juga loh......untuk spesifikasi silahkan lihat sendiri <br/>\r\nTerbuat dari wall dan bahan tambahan berkualitas lainnya.. :\r\n<br/>\r\n<br/>\r\n- Ukuran : L,M,XL<br/>\r\n- Harga : Rp. 200.000,-<br/>\r\n- Warna : Biru + Hitam<br/>\r\n<br/>\r\nUntuk Ketersediaan Hub. Service Center kami melalui Link yang telah ada... ', 'Admin', '2013-05-11 23:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id_category` varchar(25) NOT NULL,
  `category_name` text NOT NULL,
  `tanggal` varchar(25) NOT NULL,
  PRIMARY KEY (`id_category`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id_category`, `category_name`, `tanggal`) VALUES
('category_1', 'Jaket', '16/04/2013');

-- --------------------------------------------------------

--
-- Table structure for table `guestbook`
--

CREATE TABLE IF NOT EXISTS `guestbook` (
  `no_id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(50) NOT NULL,
  `komentar` text NOT NULL,
  `waktu` varchar(50) NOT NULL,
  PRIMARY KEY (`no_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `guestbook`
--

INSERT INTO `guestbook` (`no_id`, `nama`, `email`, `website`, `komentar`, `waktu`) VALUES
(7, 'Khoirul Umam', 'ngeposta@gmail.com', 'www.cahpekalongan.com', 'Websitenya bagus dan menarik sekali, tampilannya seger dan enak di pandang :D.', '13/04/2013 | 22:07 PM'),
(8, 'Fina Rizky Septiani', 'finarizky@yahoo.co.id', '', 'Selamat malam mas bro... websitenya seger banget nih, enak di pandang. Sukses terus ya...', '13/04/2013 | 22:09 PM'),
(9, 'Jonathan Smith', 'jonsmith@hotmail.com', 'www.jonathansmith.org', 'Hi there! Your website is so amazing and great. I really like this, it has nice appearance and colors...', '13/04/2013 | 22:23 PM'),
(11, 'Muh. Johandi Yahya', 'jo@ymail.com', '', 'weehhh.. keren abis brooh', '29/04/2013 | 13:56 PM'),
(12, 'rumsiti', 'rumsiti_pw@yahoo.com', '', 'waahh...mantaps ang..postingannya keren".. n desaign webnya mantaps......', '04/05/2013 | 03:40 AM'),
(13, 'Ruslan', 'ruslan.chasep@gmail.com', '', '<h2><span style="font-weight: bold;">test test</span> di coba <span style="font-size: x-large;">123</span> <span style="font-weight: bold;">test test </span>123</h2>', '07/05/2013 | 13:10 PM'),
(14, 'Ruslan', 'ruslan.chasep@gmail.com', '', '<h5><span style="font-family: impact;">ayo&nbsp; ayo...</span></h5>', '07/05/2013 | 13:11 PM'),
(15, 'adi subuh', 'adisubuh@gmail.com', '', 'test test..mau eror<br>', '07/05/2013 | 13:14 PM'),
(16, 'nava', 'nava@gmail.com', '', 'test 123<br>', '07/05/2013 | 13:18 PM');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `no_id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(25) NOT NULL,
  `jns_kelamin` varchar(15) NOT NULL,
  `ttl` varchar(50) NOT NULL,
  `agama` varchar(25) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `hobi` varchar(25) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `website` varchar(50) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(30) NOT NULL,
  `register_on` varchar(25) NOT NULL,
  PRIMARY KEY (`no_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`no_id`, `nama`, `jns_kelamin`, `ttl`, `agama`, `alamat`, `email`, `hobi`, `pekerjaan`, `website`, `username`, `password`, `register_on`) VALUES
(1, 'Muhammad Adi Subuh Hadir', 'Laki - Laki', 'Pekalongan, 13/07/1996', 'Islam', '', 'adi@rocketmail.com', '', '', '', 'adi_mh', 'adi123', '17/04/2013'),
(2, 'Moch. Imam Farisi', 'Laki - Laki', 'Pekalongan, 13/05/1997', 'Islam', '', 'faris@gmail.com', '', '', '', 'faris88', 'faris88', '28/04/2013'),
(3, 'Ainur Rifki Fadli Aulia', 'Laki - Laki', 'Denpasar, 13/04/1994', 'Islam', '', 'aulia@ymail.com', '', '', '', 'rifki12', 'rifki12', '29/04/2013'),
(4, 'Muh. Johandi Yahya', 'Laki - Laki', 'Pekalongan, 15/12/1995', 'Islam', '', 'jo@ymail.com', '', '', '', 'joe2', 'joe2', '29/04/2013');

-- --------------------------------------------------------

--
-- Table structure for table `polling`
--

CREATE TABLE IF NOT EXISTS `polling` (
  `jelek` int(10) NOT NULL,
  `sedang` int(10) NOT NULL,
  `bagus` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `polling`
--

INSERT INTO `polling` (`jelek`, `sedang`, `bagus`) VALUES
(7, 13, 34);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
